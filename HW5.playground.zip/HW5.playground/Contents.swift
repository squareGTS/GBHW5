import UIKit


protocol Car {
    var model: String {get}
    var year: Int {get}
    var capacityOfTrunk: Int {get set}
    var engine: Bool {get set}
    var windowsOpen: Bool {get set}
    
    func change()
    
}

class TrunkCar: Car {
    var model: String
    var year: Int
    var capacityOfTrunk: Int
    var engine: Bool
    var windowsOpen: Bool
    
    init(model: String, year: Int, capacityOfTrunk: Int, engine: Bool, windowsOpen: Bool) {
        self.model = model
        self.year = year
        self.capacityOfTrunk = capacityOfTrunk
        self.engine = engine
        self.windowsOpen = windowsOpen
    }
    
    func change() {
        print("switch cargo to another one")
    }
    
    var numberOfWheels = Int()
    var amounOfGears = Int()
}

class SportCar: Car {
    var model: String = "BMW"
    var year: Int = 2010
    var capacityOfTrunk: Int {
        get {
            return 200
        }
        set {
            engine = false
        }
    }
    var engine: Bool = false
    var windowsOpen: Bool = true
    
    func change() {
        print("switch driver to another one")
    }
    
    var highSpeed = Int()
    var hoursePower = Int()
}

extension Car {
    func engine() {
        print("Engine started")
    }
    func windows() {
        print("Windows closed")
        
    }
    func openClose() {
        print("dors closed")
    }
}

extension SportCar: CustomStringConvertible {
    var description: String {
        return "\(model)\n \(year)\n \(capacityOfTrunk)\n \(engine)\n \(windowsOpen)\n"
    }
    
    
}

extension TrunkCar: CustomStringConvertible {
    var description: String {
        return "\(model)\n \(year)\n \(capacityOfTrunk)\n \(engine)\n \(windowsOpen)\n"
    }
}

var sportCar = SportCar()
var sportCar1 = SportCar()
var trunkCar = TrunkCar(model: "Man", year: 2020, capacityOfTrunk: 5000, engine: true, windowsOpen: true)
var trunkCar1 = TrunkCar(model: "Mercedes", year: 2015, capacityOfTrunk: 10000, engine: false, windowsOpen: false)

sportCar.engine
sportCar.capacityOfTrunk = 200
sportCar.engine = true
trunkCar.amounOfGears = 10
trunkCar.change()
trunkCar.windows()
trunkCar1.openClose()
trunkCar1.windows()
sportCar1.highSpeed = 400
sportCar1.change()
sportCar1.model = "Ferrari"

print(sportCar)
print(sportCar1)
print(trunkCar)
print(trunkCar1)
